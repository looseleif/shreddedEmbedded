import React from "react";
 
import Camera from "./Camera";
 
export default function App() {
  return (
    <div className="App">
      <Camera />
    </div>
  );
}